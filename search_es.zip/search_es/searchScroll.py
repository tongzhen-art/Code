
class ElasticScroll:
    def __init__(self, conn, query, index, data_type):
        self.conn = conn
        self.query = query
        self.index = index
        self.data_type = data_type

    def search(self):
        try:
            return self.conn.search(
                index=self.index,
                body=self.query,
                doc_type=self.data_type,
                scroll='2m'
            )
        except Exception as e:
            print(str(e))
            pass
