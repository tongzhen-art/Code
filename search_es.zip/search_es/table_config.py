# -*- coding:utf8 -*-
from collections import OrderedDict
#定义每个索引值
def search_index(index_name):
    if index_name == 'situation-web_trojan':
        # 网站挂马002
        web_trojan = OrderedDict()
        web_trojan["domain"] = 'null'
        web_trojan["event_level"] = 'null'
        web_trojan["event_type"] = 'null'
        web_trojan["@timestamp"] = 'null'
        web_trojan["dcounty"] = 'null'
        web_trojan["s_location"] = 'null'
        web_trojan["event_id"] = 'null'
        web_trojan["industry_id"] = 'null'
        web_trojan["organization_name"] = 'null'
        web_trojan["system_id"] = 'null'
        web_trojan["found_time"] = 'null'
        web_trojan["vendor"] = 'null'
        web_trojan["description"] = 'null'
        web_trojan["data_type"] = 'null'
        web_trojan["event_token"] = 'null'
        web_trojan["organization_id"] = 'null'
        web_trojan["xujia_text"] = 'null'
        web_trojan["dcity"] = 'null'
        web_trojan["xujia_list"] = 'null'
        web_trojan["industry_name"] = 'null'
        web_trojan["trojan"] = 'null'
        web_trojan["url"] = 'null'
        web_trojan["dip"] = 'null'
        web_trojan["d_location"] = 'null'
        web_trojan["solution"] = 'null'
        web_trojan["event_subtype"] = 'null'
        web_trojan["dprovince"] = 'null'
        web_trojan["@version"] = 'null'
        return web_trojan
    elif index_name =='situation-malware':
        # 恶意软件僵木蠕毒006
        malware = OrderedDict()
        malware["@timestamp"] = 'null'
        malware["@version"] = 'null'
        malware["alert_name"] = 'null'
        malware["back_up"] = 'null'
        malware["compaign"] = 'null'
        malware["confidence"] = 'null'
        malware["current_status"] = 'null'
        malware["d_location"] = 'null'
        malware["data_type"] = 'null'
        malware["dcity"] = 'null'
        malware["dcounty"] = 'null'
        malware["description"] = 'null'
        malware["dip"] = 'null'
        malware["dport"] = 'null'
        malware["dprovince"] = 'null'
        malware["ename"] = 'null'
        malware["event_id"] = 'null'
        malware["event_level"] = 'null'
        malware["event_subtype"] = 'null'
        malware["event_token"] = 'null'
        malware["event_type"] = 'null'
        malware["file_name"] = 'null'
        malware["found_time"] = 'null'
        malware["geo_dip"] = 'null'
        malware["geo_sip"] = 'null'
        malware["industry_id"] = 'null'
        malware["industry_name"] = 'null'
        malware["ioc"] = 'null'
        malware["kill_chain"] = 'null'
        malware["malicious_family"] = 'null'
        malware["malicious_type"] = 'null'
        malware["malware_count"] = 'null'
        malware["malware_md5"] = 'null'
        malware["malware_sha1"] = 'null'
        malware["malware_type"] = 'null'
        malware["mid"] = 'null'
        malware["nid"] = 'null'
        malware["organization_id"] = 'null'
        malware["organization_name"] = 'null'
        malware["platform"] = 'null'
        malware["risk"] = 'null'
        malware["rule_desc"] = 'null'
        malware["rule_id"] = 'null'
        malware["rule_type"] = 'null'
        malware["s_location"] = 'null'
        malware["serial_num"] = 'null'
        malware["sess_id"] = 'null'
        malware["sip"] = 'null'
        malware["skyeye_id"] = 'null'
        malware["skyeye_index"] = 'null'
        malware["skyeye_type"] = 'null'
        malware["solution"] = 'null'
        malware["sport"] = 'null'
        malware["system_id"] = 'null'
        malware["tag"] = 'null'
        malware["targeted"] = 'null'
        malware["vendor"] = 'null'
        return malware
    else:
        return('input error args')












