import elasticsearch

class ElasticConnect:
    def __init__(self, ip):
        self.ip = ip

    def connect(self):
        conn = elasticsearch.Elasticsearch(
            [self.ip],
            port=9200
        )
        return conn
