# -*- coding:utf-8 -*-
import sys
import os

# 将source下的文件添加至Python 系统变量中__file__
sys.path.append(os.path.abspath('__file__'))
from connES import *
from searchScroll import *
import re
import time
import  table_config

reload(sys)
sys.setdefaultencoding('utf8')

#  D:\python\elasticsearch\mainSearch.py  10.95.32.24  situation-web_trojan  situation-web_trojan
#  D:\python\elasticsearch\mainSearch.py  10.95.32.24  situation-malware situation-malware
#  print  sys.path[0]

try:
    ip = sys.argv[1]
    index_name = sys.argv[2]
    data_type = sys.argv[3]
except IndexError as a:
    print("please input serviceIP and index_name and  data_type")
    ip = '10.95.32.24'
    index_name = 'skyeye-tcpflow-2019.01.25'
    data_type = 'skyeye-tcpflow'
    exit(-1)
# 定义查询
query = {
    # 定义返回数据量
    "size": 10000,
    "query": {
        # 定义查询条件，默认无条件
        #"match_all": { } #查询全部数据。
        #"range": {'@timestamp': {'gt': 'now-1d'}}   #查询当天新增数据
         "match": {
             "nid": '5782621921543849811'
         }
    }
}
# 建立es连接实例
conn = ElasticConnect(ip).connect()
# 建立es实例
es = ElasticScroll(conn, query, index_name, data_type)
# es执行查询
page = es.search()
# 获取 sid翻页id

# 获取数据量print(page)
# sid = page['_scroll_id']
# print(sid)值
#print(sid)
count = len(page["hits"]["hits"])
print(count)
file_name = 0
while count > 0:
    # dsl搜索返回结果集 字典格式
    page = conn.scroll(scroll_id=sid, scroll='2m')
    print(page)
    # 获取数据量值
    count = len(page["hits"]["hits"])
    print(count)
    # 获取全部数据
    res = page["hits"]["hits"]
    # 写入文件
    #data_path = data_type[]
    #with open(sys.path[0] + "/data/"+data_type +"_file_" + str(file_name), "a") as f:
    with open(sys.path[0] + "/data/"+data_type+"/"+data_type +"_file_" + str(file_name), "a") as f:
        for i in res:
            dic = i["_source"]
            line = ""
            #for v in dic.values():
            for key, value in dic.items():
            #     print(key, v)
            #     cell = str(v) + "\t"
            #     cell = cell.replace("\n", "")
            #     line += cell
            # line = re.sub("\t$", "\r", line)
                #print(key)
                # 获取有序的字段顺序
                dict = table_config.search_index(data_type)
                # 获取dic 中能够与 dict 映射上的key
                try:
                    keys = (keys for keys, value in dict.items() if str(keys) == str(key))
                #获取key
                    k = next(keys)
                except Exception as e:
                    print(key)
                    continue
                # 将value赋值给索引中对应的key
                dict[k] = value
            times = time.strftime('%Y-%m-%d %Y:%M:%S', time.localtime(time.time()))  #提取时间
            #print(times)
            #print(dict.values())
            for key, v in dict.items():
                cell = str(v) + "\t"
                #cell = cell.replace("\n", "").replace("\r", "")
                cells =  cell.strip()
                #cell = cell.strip()
                line += cells
            line = re.sub("\t$", "\r", line)
            lines = times + "\t" + line     # 生成时间
            #print (lines)
            f.write(lines)
    print("successfully write file file_%s" % str(file_name))
    file_name += 1



